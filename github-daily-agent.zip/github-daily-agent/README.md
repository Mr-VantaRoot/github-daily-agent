# GitHub Daily Agent

A scheduled GitHub repository maintenance agent. It scans an explicit allowlist, reports actionable repository-health findings, and can open deduplicated issues. It never manufactures commits or edits project source files merely to create contribution activity.

## Features

- Daily scan at 06:00 Ethiopia time (03:00 UTC).
- Explicit repository allowlist; no account-wide discovery at runtime.
- Read-only repository inspection plus optional issue creation.
- Detects missing README, missing test directory, missing CI workflow, and repository workflow hygiene issues.
- Deduplicates issues before creating them.
- Writes a Markdown report and uploads it as a workflow artifact.
- Manual `workflow_dispatch` trigger.
- No LLM/API billing dependency; Python standard library only.

## Safety model

The initial release **does not autonomously rewrite application code, merge pull requests, change default branches, or create artificial commits**. It opens an issue only when a configured, actionable finding is present and no matching open issue already exists. Findings are suggestions, not proof of a vulnerability or defect.

Do not grant this agent admin, secrets, deployment, or organization-management permissions. Review generated issues before acting on them.

## 1. Create the agent repository

Create a new repository named `github-daily-agent` under your GitHub account. Do not initialize it with a README if you intend to push this project as-is.

Extract this project, then from its directory:

```bash
git init
git add .
git commit -m "Initial GitHub Daily Agent"
git branch -M main
git remote add origin https://github.com/Mr-VantaRoot/github-daily-agent.git
git push -u origin main
```

If the repository already exists and has files, clone it first and copy these files into it instead of replacing its history.

## 2. Create a fine-grained personal access token

In GitHub, open **Settings → Developer settings → Personal access tokens → Fine-grained tokens**.

Create a token with:
- Resource owner: `Mr-VantaRoot`
- Repository access: **Only select repositories**
- Select the seven repositories in `config.yaml` plus `github-daily-agent` only if needed for private access (the workflow uses its built-in token for the agent repo).
- Repository permissions:
  - Metadata: Read-only
  - Contents: Read-only
  - Issues: Read and write

Do not grant Administration, Actions, Workflows, Secrets, Deployments, or Contents write. The agent's initial mode only reads repository content and creates issues.

Copy the token once. In the `github-daily-agent` repository, open **Settings → Secrets and variables → Actions → New repository secret**:
- Name: `GH_AGENT_TOKEN`
- Value: your fine-grained token

The token must be authorized for every selected target repository. If GitHub organization policies restrict fine-grained tokens, follow the organization policy rather than broadening permissions unnecessarily.

## 3. Configure selected repositories

Edit `config.yaml`. The included allowlist contains:

- `Mr-VantaRoot/port_scanner`
- `Mr-VantaRoot/Network-Monitor`
- `Mr-VantaRoot/file_encryptor`
- `Mr-VantaRoot/password_checker.py`
- `Mr-VantaRoot/check_ip.py`
- `Mr-VantaRoot/Birhanguard`
- `Mr-VantaRoot/milky-smiles-connect`

Remove or add repositories deliberately. Runtime scanning is restricted to this list.

## 4. Run locally on Fedora

Python 3.10+ is recommended. No third-party packages are required.

```bash
python3 -m venv .venv
source .venv/bin/activate
export GH_AGENT_TOKEN="YOUR_FINE_GRAINED_TOKEN"
python -m github_daily_agent --config config.yaml
```

The command prints a summary and writes `reports/latest.md`. Keep the token in an environment variable; never put it in YAML, source code, or commit history.

## 5. Enable scheduled execution

Push the project to GitHub. The workflow at `.github/workflows/daily-scan.yml` runs daily at `03:00 UTC` (06:00 Ethiopia time) and can also be started manually from **Actions → Daily Repository Scan → Run workflow**.

GitHub scheduled workflows can be delayed during high load and may be disabled in inactive public repositories. Check the Actions tab to verify runs.

## 6. What it does and does not contribute

It can create a meaningful GitHub issue when a repository has a real, detected maintenance gap. It will not create empty commits, daily diary commits, cosmetic file edits, or duplicate issues to manipulate the contribution graph. GitHub decides which activities appear in the contribution graph; an automated run does not guarantee a green square.

## Configuration

See `config.yaml` for:
- `repositories`: strict allowlist
- `create_issues`: enable/disable issue creation
- `checks`: individual checks
- `max_issues_per_run`: safety cap
- `report_dir`: local report output

## Troubleshooting

- **401/403:** Check token expiry, selected repositories, and `Metadata: read`, `Contents: read`, `Issues: read/write`.
- **Repository not found:** The token may not include that repository, or the repository name may be wrong.
- **No issue created:** The finding may be disabled, an equivalent open issue may already exist, or `create_issues` may be false.
- **No daily run:** Check Actions permissions and the repository's Actions tab. Start a manual run to test.
- **No contribution square:** GitHub contribution rules apply; issue creation is not a guaranteed daily contribution.

## License

MIT. See `LICENSE`.
